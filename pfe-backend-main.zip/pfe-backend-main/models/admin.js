const mongoose = require('mongoose');
const admin=mongoose.model('admin',{
name:{
    type :String,
    required:true,
},
description:{
    type :String,
    required:true,
   
}






})
module.exports=admin;