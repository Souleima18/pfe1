const express = require('express');



const router = express.Router();
const {get_profile_user, update_compte_user, update_profile_user, update_photo_profil, add_new_user, delete_user}= require('../controllers/admin');
router.post('/get_profile_user',get_profile_user);
router.post('/update_compte_user',update_compte_user);
router.post('/update_profile_user',update_profile_user);
router.post('/update_photo_profil',update_photo_profil);
router.post('/add_new_user',add_new_user);
router.post('/delete_user',delete_user);
module.exports=router;