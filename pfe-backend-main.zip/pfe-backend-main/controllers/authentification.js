var jwt = require('jsonwebtoken');
var cookieParser = require('cookie-parser');
const isAuth = require('./_helpers/isAuth')
const mongoose = require('mongoose');
var bcrypt = require('bcrypt');
var nodemailer = require('nodemailer');
var saltRounds = 10;
var sessions = require('express-session');
var session;
var dbconfig = require('../../config/connect');
// Connect to MongoDB using Mongoose
mongoose.connect(dbconfig.connection, { useNewUrlParser: true, useUnifiedTopology: true }); // Use Mongoose to connect to MongoDB

// Define the schema for the user model
const userSchema = new mongoose.Schema({
    email: String,
    password: String,
    nom: String
});

// Create a model from the schema
const User = mongoose.model('User', userSchema);

module.exports = function(app) {
    app.post('/login', function(req, res, next) {
        let emp = req.body;
        // Find the user in MongoDB
        User.findOne({ email: emp.login }, function(error, user) {
            if (error) throw error;
            if (user) {
                // If the user is found, compare passwords
                bcrypt.compare(emp.password, user.password).then(function(result) {
                    if (result) {
                        let payload = { subject: user._id, nom: user.nom };
                        let token = jwt.sign(payload, 'secretKey');
                        console.log(token);
                        res.cookie('jwt', token, { httpOnly: true, maxAge: 60 * 60 * 1000 * 24 * 7 });
                        res.json({ msg: 'success' });
                    } else {
                        res.json({ msg: 'password-incorrect' });
                    }
                });
            } else {
                res.json({ msg: 'not-exist' });
            }
        });
    });
};
