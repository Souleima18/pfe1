var jwt = require('jsonwebtoken');
var cookieParser = require('cookie-parser');


module.exports = isNotAuth;

    function  isNotAuth (req, res, next)  {


        let token = req.cookies.jwt;

        if(typeof token === 'undefined'  ){
            return res.render('login');
        }

        if( !token){
            return res.render('login');
        }

        if( token === 'null' ){
            return res.render('login');
        }

        let payload  =jwt.verify(token, 'secretKey')
        if( !payload){
            return res.render('login');
        }

        return res.redirect('/accueil');
        next()
}  
