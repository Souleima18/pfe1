var jwt = require('jsonwebtoken');
var cookieParser = require('cookie-parser');


module.exports = isAuth;

    function isAuth  (req, res, next) {


        let token = req.cookies.jwt;
        
        if(typeof token === 'undefined'  ){
            return res.redirect('/')
        }

        if( !token){
            return res.redirect('/')
        }

        if( token === 'null' ){
            return res.redirect('/')
        }


        let payload  =jwt.verify(token, 'secretKey')
        if( !payload){
            return res.redirect('/')
        }

        req.userId = payload.subject
        req.data = {nom :payload.nom,uniqueTypeCompte:"Admin"}
        next()
   
    }      
