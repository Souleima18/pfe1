const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const isAuth = require('./_helpers/isAuth');
const bcrypt = require('bcrypt');
const saltRounds = 10;
const multer = require('multer');
const mongoose = require('mongoose');
const dbconfig = require('../../config/connect');

// Connect to MongoDB using Mongoose
mongoose.connect(dbconfig.connection, { useNewUrlParser: true, useUnifiedTopology: true });

// Define the user schema
const userSchema = new mongoose.Schema({
    nom: String,
    email: String,
    adresse: String,
    telephone: String,
    password: String,
    avatar: String
});

// Create a model from the schema
const User = mongoose.model('User', userSchema);

// Multer storage configuration
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'public/img/avatar/');
    },
    filename: function (req, file, cb) {
        cb(null, file.fieldname + Date.now() + '.' + file.mimetype.split('/')[1]);
    }
});

// Multer upload configuration
const upload = multer({ storage: storage, limits: { fileSize: 1024 + 1024 * 5 } });

module.exports = function (app) {
    // Get user profile
    app.post('/get_profile_user', isAuth, function (req, res, next) {
        User.findById(req.userId, function (error, user) {
            if (error) throw error;
            if (user) {
                res.json({ msg: { user } });
            } else {
                res.json({ msg: 'echec' });
            }
        });
    });

    // Update user password
    app.post('/update_compte_user', isAuth, function (req, res, next) {
        let emp = req.body;
        User.findById(req.userId, function (error, user) {
            if (error) throw error;
            if (user) {
                bcrypt.compare(emp.ancien_password, user.password).then(function (result) {
                    if (result) {
                        bcrypt.hash(emp.nouveau_password, saltRounds, function (err, hash) {
                            User.findByIdAndUpdate(req.userId, { password: hash }, function (error, updatedUser) {
                                if (error) throw error;
                                res.json({ msg: 'success' });
                            });
                        });
                    } else {
                        res.json({ msg: 'error' });
                    }
                });
            } else {
                res.json({ msg: 'error' });
            }
        });
    });

    // Update user profile
    app.post('/update_profile_user', isAuth, function (req, res, next) {
        let emp = req.body;
        User.findByIdAndUpdate(req.userId, {
            nom: emp.nom,
            email: emp.email,
            adresse: emp.adresse,
            telephone: emp.telephone
        }, function (error, updatedUser) {
            if (error) throw error;
            let payload = { subject: req.userId, nom: emp.nom };
            let token = jwt.sign(payload, 'secretKey');
            res.cookie('jwt', token, { httpOnly: true, maxAge: 60 * 60 * 1000 });
            res.json({ msg: 'success' });
        });
    });

    // Update user profile photo
    app.post('/update_photo_profil', isAuth, upload.single('avatar'), function (req, res, next) {
        if (req.file) {
            User.findByIdAndUpdate(req.userId, { avatar: req.file.filename }, function (error, updatedUser) {
                if (error) throw error;
                res.json({ msg: 'success' });
            });
        } else {
            res.json({ msg: 'vide' });
        }
    });

    // Ajouter un nouveau compte utilisateur
    app.post('/add_new_user', function (req, res, next) {
        let emp = req.body;
        bcrypt.hash(emp.password, saltRounds, function (err, hash) {
            if (err) throw err;
            const newUser = new User({
                nom: emp.nom,
                email: emp.email,
                adresse: emp.adresse,
                telephone: emp.telephone,
                password: hash,
                avatar: emp.avatar // Ajoutez la logique pour l'avatar si nécessaire
            });
            newUser.save(function (error, savedUser) {
                if (error) throw error;
                res.json({ msg: 'success' });
            });
        });
    });

    // Supprimer un compte utilisateur
    app.post('/delete_user', isAuth, function (req, res, next) {
        User.findByIdAndDelete(req.userId, function (error, deletedUser) {
            if (error) throw error;
            if (deletedUser) {
                res.json({ msg: 'success' });
            } else {
                res.json({ msg: 'echec' });
            }
        });
    });
};
